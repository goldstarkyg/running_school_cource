<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <title>Contact Email</title>
  <meta name="description" content="">
  <!-- Bootstrap core CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">

  <link rel="stylesheet" href="./assets/css/style.css">
  <link rel="stylesheet" href="./assets/css/custom.css">
</head>
<body style="margin-top: 0px ; padding-top: 0px;">
    <div class="row m-0 bg-default">
      <div class="container f-1-2">
        <div class="text-left t-space-2 b-space-2">Test for Mail Management</div>
        <form name="email_form" id="email_form" action="./mail/school/testmail.php" method="post" >
            <div class="text-left t-space-2">
                <span class="color-red">※</span>
                Sender email
            </div>
            <div class="row m-0 t-space-2">
                <input type="text" name="sender_email" class="c-width--100 c-input">
            </div>
            <div class="text-left t-space-2">
                <span class="color-red">※</span>
                Sender name
            </div>
            <div class="row m-0 t-space-2">
                <input type="text" name="sender_name" class="c-width--100 c-input">
            </div>
            <div class="text-left t-space-2">
                <span class="color-red">※</span>Subject
            </div>
            <div class="row m-0 t-space-2">
                <input type="text" name="subject" class="c-width--100 c-input">
            </div>
            <div class="text-left t-space-2">
                <span class="color-red">※</span>
                Email Content
            </div>
            <div class="row m-0 t-space-2">
              <textarea type="text" name="content" class="c-width--100 c-input">
               </textarea>
            </div>
            <div class="text-left t-space-2">
                <span class="color-red">※</span>
                Email List
            </div>
            <div class="row m-0 t-space-2">
                <input type="text" name="email_list" class="c-width--100 c-input"></div>
            <div class="row far-y-5">
              <input type="submit" value="Send Email" class="c-btn c-btn--green w40 f-1-2">
            </div>
        </form>
      </div>
    </div>
</div>










  <!-- Bootstrap core JavaScript -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>  </body>

  <script src="./assets/js/app.js"></script>
</body>
</html>