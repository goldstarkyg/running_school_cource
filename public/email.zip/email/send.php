<?php
    $item_check = true;
    if (!empty($_POST))
    {
        if($_POST['sender_email']) {
            $send_email = $_POST['sender_email'];
        }else {
            $item_check = false;
        }
        if($_POST['sender_name']) {
            $sender_name = $_POST['sender_name'];
        }else{
            $item_check = false;
        }
        if($_POST['subject']) {
            $subject = $_POST['subject'];
        }else{
            $item_check = false;
        }
        if($_POST['content']) {
            $content = $_POST['content'];
        }else {
            $item_check = false;
        }
        if($_POST['email_list']) {
            $email_list = $_POST['email_list'];
        }else {
            $item_check = false;
        }

        if($item_check == false) {
            echo "Please check all items, and enter <br>";
            echo "<a href='./contact.php'>Go to contact page</a>";
        }

    }
?>